from django.db import models

# Create your models here.
class Agent(models.Model):
    agtid=models.IntegerField()
    name=models.CharField(max_length=100)
    salary=models.IntegerField()
