from django.urls import path

from .api import AgentCreateApi,AgentApi, AgentDeleteApi,AgentDeleteApi,AgentUpdateApi

urlpatterns = [

    path('api/',AgentApi.as_view()),

    path('api/create',AgentCreateApi.as_view()),
    path('api/delete/<int:pk>',AgentDeleteApi.as_view()),
    path('api/update/<int:pk>',AgentUpdateApi.as_view()),

]
'''
[11:58 AM] Bhalerao, Gitanjali

urlpatterns = [
path('api/',AgentApi.as_view()),
path('api/create',AgentCreateApi.as_view()),
path('api/<int:pk>',AgentUpdateApi.as_view()),
path('api/<int:pk>/delete',AgentDeleteApi.as_view()),
]


'''