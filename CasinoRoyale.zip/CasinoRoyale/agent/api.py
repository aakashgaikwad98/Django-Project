from rest_framework import generics

from rest_framework.response import Response

from .serializer import AgentSerializer

from .models import Agent


class AgentCreateApi(generics.CreateAPIView):

    queryset = Agent.objects.all()

    serializer_class = AgentSerializer



class AgentApi(generics.ListAPIView):
    queryset = Agent.objects.all()
    serializer_class = AgentSerializer

class AgentUpdateApi(generics.RetrieveUpdateAPIView):
    queryset = Agent.objects.all()
    serializer_class = AgentSerializer

class AgentDeleteApi(generics.DestroyAPIView):
    queryset=Agent.objects.all()
    serilizer_class=AgentSerializer